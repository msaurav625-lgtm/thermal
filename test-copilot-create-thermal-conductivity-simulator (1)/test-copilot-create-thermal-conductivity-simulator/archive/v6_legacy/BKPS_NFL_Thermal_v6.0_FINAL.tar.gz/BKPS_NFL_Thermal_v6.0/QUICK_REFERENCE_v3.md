# Nanofluid Simulator v3.0 - Quick Reference

## 🆕 What's New in v3.0

### Popup Windows (Reduce Clutter)
- **Advanced Configuration Dialog**: Access via "⚙️ Advanced Configuration" button
  - Particle shapes: Sphere, Rod/Cylinder, Cube, Platelet, Irregular
  - Shape parameters: Aspect ratio (0.1-100), Sphericity (0.1-1.0)
  - Surface properties: Interfacial layer (0-10 nm), Surface energy (0-1000 mJ/m²)
  - Aggregation toggle
  - Temperature range setup
  
- **Nanoparticle Observer Dialog**: Access via "🔬 Nanoparticle Observer" button
  - 4-panel visualization
  - Size distribution histogram
  - Aggregation probability
  - Surface interaction potential curves
  - Particle shape schematic

### Multiple Particle Shapes
| Shape | Aspect Ratio | Sphericity | Best For |
|-------|-------------|-----------|----------|
| Sphere | 1.0 | 1.0 | General purpose, easy analysis |
| Rod/Cylinder | 2-20 | 0.5-0.8 | CNTs, nanowires, fibers |
| Cube | 1.0 | 0.806 | Cubic nanoparticles |
| Platelet | 0.1-0.5 | 0.3-0.6 | Graphene, nanosheets |
| Irregular | Variable | <0.5 | Complex morphologies |

### Temperature Range Analysis
**New Input Fields:**
- Min Temperature: 273-500 K
- Max Temperature: 273-500 K  
- Current Point: For single calculations
- Number of Points: 5-100 for range plots

**New "📈 Temp Range" Tab:**
- Plots k_nf vs Temperature
- Compares Maxwell, Hamilton-Crosser, Yu-Choi models
- Shows temperature-dependent behavior
- Scientific formatting

### Scientific-Grade Graphs
All plots now feature:
- ✓ Scientific notation on axes (e.g., 1.5×10³)
- ✓ Bold titles and axis labels
- ✓ Proper units in labels
- ✓ Grid lines with transparency
- ✓ High-resolution exports (300 DPI)
- ✓ Color-coded legends
- ✓ Publication-ready quality

### Surface Interactions Tab
New "🔗 Surface Effects" tab with 4 plots:

1. **Interfacial Layer Effect**
   - Shows k/k_bulk vs distance from surface
   - Red dashed line marks interfacial layer thickness
   - Demonstrates nanolayer conductivity enhancement

2. **Aggregation Energy**
   - Bar plot of surface energy vs aggregate size
   - Energy decreases with aggregation
   - Only active if aggregation enabled

3. **Brownian Motion**
   - Mean square displacement vs time
   - Calculated from Brownian diffusivity
   - Shows particle mobility

4. **Concentration Profile**
   - Volume fraction vs height
   - Shows sedimentation effects
   - Compares to uniform distribution

### Refresh/Reset Functions
**"🔄 Refresh/Reset Results" Button:**
- Clears all plots
- Clears results display
- Keeps parameter settings
- Confirmation dialog before clearing

**Menu: Tools > Reset to Defaults (Ctrl+R):**
- Resets ALL parameters to defaults
- Cu in Water at 2% vol fraction
- 300 K, 40 nm particles
- Channel flow, Re=1000

### Save Results Options
**"💾 Save Results" Button (Ctrl+S):**
- Text format: Includes results text + JSON data
- JSON format: Machine-readable data only
- Timestamped filenames
- Saves: particle, fluid, properties, conditions

**File > Export All Data:**
- Saves all 6 plots as PNG (300 DPI)
- Saves results.txt
- Saves data.json
- All timestamped in selected folder

## 📋 Feature Checklist

- [x] Popup windows for advanced config
- [x] Multiple particle shapes (5 types)
- [x] Rod, cube, and other geometries
- [x] User input temperature range
- [x] Scientific-grade graphs
- [x] Nanoparticle observer
- [x] Surface interactions visualization
- [x] Refresh/reset icon and function
- [x] Save results (TXT, JSON)
- [x] Export all data and plots

## 🎨 UI Layout

```
┌─────────────────────────────────────────────────────────┐
│ Menu Bar: File | Tools | Help                           │
├──────────────┬──────────────────────────────────────────┤
│              │                                          │
│  Control     │  Visualization Tabs                      │
│  Panel       │  ┌────────────────────────────────────┐ │
│  (30%)       │  │ 🌡️ | ➡️ | 〰️ | 📊 | 📈 | 🔗      │ │
│              │  └────────────────────────────────────┘ │
│ ┌──────────┐ │                                          │
│ │Materials │ │  [Plot Area with Toolbar]                │
│ │& Shape   │ │                                          │
│ └──────────┘ │                                          │
│ ┌──────────┐ │                                          │
│ │Flow      │ │                                          │
│ │Config    │ │                                          │
│ └──────────┘ │                                          │
│ ┌──────────┐ │                                          │
│ │Temp      │ │                                          │
│ │Range     │ │                                          │
│ └──────────┘ │                                          │
│ ┌──────────┐ │                                          │
│ │Buttons   │ │                                          │
│ └──────────┘ │                                          │
│ ┌──────────┐ │                                          │
│ │Results   │ │                                          │
│ └──────────┘ │                                          │
├──────────────┴──────────────────────────────────────────┤
│ Status Bar: Ready                          [Progress]   │
└─────────────────────────────────────────────────────────┘
```

## 🔧 Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+S | Save Results |
| Ctrl+R | Reset to Defaults |
| Ctrl+Q | Quit Application |

## 📊 Visualization Tabs

1. **🌡️ Thermal Contours**: Temperature distribution with color map
2. **➡️ Velocity Field**: Vector arrows with magnitude coloring
3. **〰️ Streamlines**: Flow pathlines with thermal overlay
4. **📊 Full Analysis**: 4-panel comprehensive view
5. **📈 Temp Range**: k_nf vs Temperature (NEW!)
6. **🔗 Surface Effects**: Interfacial, Brownian, aggregation (NEW!)

## 🎯 Common Workflows

### Heat Exchanger Design
```
1. Select Cu nanoparticle
2. Set volume fraction: 2-4%
3. Base fluid: Water
4. Temperature range: 300-350 K
5. Geometry: Channel
6. Reynolds: 1000-2000
7. Click "Advanced Configuration"
   - Shape: Sphere or Rod
   - Interfacial layer: 2 nm
8. Click "Calculate & Visualize"
9. Check "Temp Range" tab
10. Save results
```

### Nanoparticle Selection Study
```
1. Open "Advanced Configuration"
2. Set temperature range: 280-370 K
3. Test different particles:
   - Cu (high k)
   - Al2O3 (stable)
   - TiO2 (low cost)
4. Compare in "Temp Range" tab
5. Use "AI Recommendations" for guidance
6. Export all data for comparison
```

### Shape Effect Analysis
```
1. Select particle (e.g., Cu)
2. Open "Advanced Configuration"
3. Test shapes:
   - Sphere (sphericity = 1.0)
   - Rod (aspect ratio = 10, sphericity = 0.5)
   - Platelet (aspect ratio = 0.2)
4. Compare enhancement percentages
5. Check "Nanoparticle Observer"
6. Save results for each shape
```

## 💡 Tips & Best Practices

### Performance
- Use grid resolution 30-50 for fast preview
- Use 60-80 for publication-quality plots
- Lower vector density for faster rendering

### Accuracy
- Enable aggregation for concentrated nanofluids (φ > 3%)
- Set appropriate interfacial layer (1-3 nm typical)
- Use temperature range that matches application

### Visualization
- Use "Thermal Contours" for temperature distribution
- Use "Velocity Field" to understand flow patterns
- Use "Streamlines" for intuitive flow visualization
- Use "Full Analysis" for comprehensive overview
- Use "Temp Range" for material comparison
- Use "Surface Effects" for physics understanding

### Saving Work
- Save as JSON for data analysis in other tools
- Save as TXT for human-readable reports
- Use "Export All Data" for complete documentation
- Name files descriptively with conditions

## 🐛 Troubleshooting

### Popup Dialogs Don't Appear
- Check if they're behind main window
- Try Alt+Tab to switch windows

### Plots Look Cluttered
- Reduce grid resolution
- Lower vector density
- Increase figure size in tab

### Calculations Slow
- Reduce grid resolution (20-40)
- Reduce temperature range points (<20)
- Close unused browser tabs/apps

### Can't See Surface Interactions
- Ensure aggregation is enabled in Advanced Config
- Check that interfacial layer > 0
- Verify particle size > 10 nm

## 📚 References

- Maxwell Model (1904): Spherical particles
- Hamilton-Crosser (1962): Non-spherical particles
- Yu-Choi (2003): Interfacial layer effects

## 🆘 Support

- GitHub Issues: Report bugs and request features
- Documentation: See docs/ folder
- Examples: See examples/ folder

---

**Version 3.0 Professional Edition**  
*All features requested: ✓ Implemented*
