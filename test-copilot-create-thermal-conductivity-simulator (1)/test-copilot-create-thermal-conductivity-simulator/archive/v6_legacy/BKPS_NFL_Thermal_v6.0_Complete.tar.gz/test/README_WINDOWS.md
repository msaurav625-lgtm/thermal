# Nanofluid Simulator - Windows Executable

## 🚀 Quick Start

1. **Extract** the downloaded ZIP file to a folder
2. **Double-click** `NanofluidSimulator.exe`
3. The app window should open in a few seconds

## ⚠️ App Won't Start?

### Most Common Issue: Missing Visual C++ Runtime

**Download and install:**
- [Microsoft Visual C++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe)

After installing, restart your computer and try again.

### Still Not Working?

**Run from Command Prompt to see errors:**

1. Open Command Prompt (search for `cmd` in Start Menu)
2. Navigate to the folder with the .exe:
   ```
   cd C:\path\to\NanofluidSimulator
   ```
3. Run the app:
   ```
   NanofluidSimulator.exe
   ```
4. Copy any error messages and check **TROUBLESHOOTING.md**

### Quick Diagnostic

Run the included diagnostic tool:
```
python diagnose.py
```

This will check if all components are working.

## 📋 System Requirements

- **Windows**: 10 or 11 (64-bit)
- **RAM**: 4 GB minimum, 8 GB recommended
- **Disk**: 500 MB free space
- **Display**: 1280x720 minimum resolution

## 🔒 Security Warning

Windows might show a security warning because the app is not digitally signed:

1. Click "More info"
2. Click "Run anyway"

This is normal for open-source applications. The source code is available for review.

## 📖 Documentation

- **QUICK_REFERENCE_v3.md** - Feature guide and shortcuts
- **TROUBLESHOOTING.md** - Detailed troubleshooting steps
- **README.md** - Full documentation
- **examples/** - Example scripts

## 🎯 Features

✅ Advanced nanofluid thermal conductivity simulator  
✅ Multiple particle shapes (sphere, rod, cube, platelet)  
✅ Flow visualization (thermal contours, velocity fields)  
✅ Temperature range analysis  
✅ Surface interaction analysis  
✅ Nanoparticle observer with 4-panel visualization  
✅ Scientific-grade graphs  
✅ Export to PNG, TXT, JSON, Excel  

## 🐛 Report Issues

If you encounter problems:

1. Check **TROUBLESHOOTING.md** first
2. Run `diagnose.py` and save the output
3. Open an issue on GitHub with:
   - Windows version (Win+R, type `winver`)
   - Error message from Command Prompt
   - Output from diagnose.py

## 🔄 Alternative: Run from Python

If the executable doesn't work, you can run from source:

### Install Python 3.10 or 3.11
https://www.python.org/downloads/

### Install dependencies:
```bash
pip install numpy scipy matplotlib PyQt6
```

### Run the app:
```bash
python run_gui_v3.py
```

## ✨ First Time Using?

1. Start with default values (Al2O3 nanoparticles in water)
2. Click **"Calculate Properties"**
3. Explore the tabs:
   - **Thermal Contours** - Temperature distribution
   - **Velocity Field** - Flow patterns
   - **Temperature Range** - k vs T plot
   - **Surface Effects** - Interfacial interactions
4. Try **Tools → Advanced Config** for more options
5. Try **Tools → Nanoparticle Observer** for detailed analysis

## 💾 Saving Your Work

- **File → Save Results** - Save calculations to TXT/JSON
- **File → Export All Data** - Save all plots + data

## ⌨️ Keyboard Shortcuts

- **Ctrl+S** - Save results
- **Ctrl+R** - Reset to defaults
- **Ctrl+Q** - Quit application
- **F1** - Help/About

## 🔗 Links

- GitHub Repository: https://github.com/msaurav625-lgtm/test
- Issues: https://github.com/msaurav625-lgtm/test/issues
- Documentation: See README.md

## 📜 License

This software is open source. See LICENSE.txt for details.

---

**Version**: 3.0  
**Build Date**: November 2025  
**Python**: 3.10.11  
**Qt**: 6.x

Need help? Check TROUBLESHOOTING.md or open an issue on GitHub!
