# BKPS NFL Thermal v6.0 - Windows Executable Guide
**Dedicated to: Brijesh Kumar Pandey**

---

## 🎯 Overview

BKPS NFL Thermal v6.0 is now available as a **standalone Windows executable (.exe)** that runs without requiring Python installation. This professional desktop application provides world-class nanofluid thermal analysis with advanced physics modeling.

---

## 📦 What's Included

### Standalone Application
- **File**: `BKPS_NFL_Thermal_v6.0.exe` (~150-200 MB)
- **No Python Required**: All dependencies bundled
- **No Installation**: Double-click to run
- **Windows 10/11**: Fully compatible

### Bundled Features
- Complete v6.0 advanced physics engine
- Flow-dependent thermal conductivity models
- Non-Newtonian viscosity calculations
- DLVO theory & colloidal stability
- 11 material database (Al₂O₃, Cu, CuO, TiO₂, Ag, SiO₂, Au, Fe₃O₄, ZnO, CNT, Graphene)
- Comprehensive analysis workflows
- Professional GUI with 4 tabs

---

## 🚀 Quick Start

### For Users (Running the Executable)

1. **Download** the executable:
   ```
   BKPS_NFL_Thermal_v6.0.exe
   ```

2. **Run** by double-clicking the file

3. **First Launch**:
   - Windows may show "Windows protected your PC" warning
   - Click "More info" → "Run anyway"
   - This is normal for unsigned executables

4. **Use the Application**:
   - **Setup Tab**: Configure base fluid, nanoparticles, conditions
   - **Analysis Tab**: Run calculations
   - **Results Tab**: View comprehensive output
   - **About Tab**: Features and documentation

### For Developers (Building from Source)

#### Prerequisites
```bash
# Install Python 3.8+ and pip
python --version

# Install dependencies
pip install numpy scipy matplotlib PyQt6 pyinstaller
```

#### Build on Windows
```batch
# Run the build script
build_bkps_exe.bat

# Or manually
pyinstaller --clean --noconfirm bkps_nfl_thermal.spec
```

#### Build on Linux/Mac
```bash
# Make script executable
chmod +x build_bkps_exe.sh

# Run build script
./build_bkps_exe.sh

# Or manually
pyinstaller --clean --noconfirm bkps_nfl_thermal.spec
```

---

## 💻 Application Interface

### 1. Setup Tab (🔧)

**Base Fluid Properties:**
- Base Fluid: Water, EG (Ethylene Glycol), Oil
- Temperature: 273-400 K
- Pressure: 1e5 - 1e7 Pa
- ☑️ Calculate base fluid only (no nanoparticles)

**Nanoparticle Properties:**
- Material: 11 options (Al₂O₃, Cu, CuO, TiO₂, Ag, etc.)
- Volume Fraction: 0-10% (default 2%)
- Diameter: 1-200 nm
- Shape: sphere, rod, sheet, tube, ellipsoid

**Environmental Conditions (DLVO):**
- pH: 2-14 (default 7)
- Ionic Strength: 0.0001-1.0 mol/L (default 0.001)

**Flow Conditions:**
- Velocity: 0-10 m/s
- Shear Rate: 0-100,000 1/s
- ☑️ Enable Non-Newtonian viscosity

### 2. Analysis Tab (📊)

Four analysis options:

**Calculate Base Fluid Properties Only** (Green Button)
- Returns: k, μ, ρ, Cp, α of pure base fluid
- Use for: Validation, comparison studies

**Calculate Static Properties (No Flow)** (Blue Button)
- Returns: k_static, μ_static, enhancement
- Models: Maxwell, Brinkman, static correlations

**Calculate Flow-Dependent Properties** (Orange Button)
- Returns: k_flow, μ_flow with flow effects
- Models: Buongiorno, Kumar, Rea-Guzman, Carreau-Yasuda

**🚀 Comprehensive Analysis (All Features)** (Purple Button)
- Returns: Complete analysis with all physics
- Includes: Static, flow, DLVO, clustering effects
- Progress bar shows calculation status

### 3. Results Tab (📈)

Displays comprehensive analysis output:
- System configuration summary
- Base fluid properties
- Static thermal conductivity & enhancement
- Flow-enhanced conductivity
- Final properties with clustering effects
- Viscosity analysis
- DLVO stability assessment
- Flow regime information
- Reynolds number

### 4. About Tab (ℹ️)

- Full feature list
- Validation information (R² = 0.932, MAPE = 10.0%)
- Documentation links
- Version info
- Dedication

---

## 📋 Typical Workflow

### Example 1: Basic Nanofluid Analysis
1. **Setup Tab**:
   - Base Fluid: Water
   - Temperature: 300 K
   - Material: Al₂O₃
   - Volume Fraction: 0.02 (2%)
   - Diameter: 30 nm

2. **Analysis Tab**:
   - Click "🚀 Comprehensive Analysis"
   - Wait for progress bar (5-10 seconds)

3. **Results Tab**:
   - View k_static = 0.649 W/m·K (+5.87%)
   - View μ_effective = 0.695 mPa·s

### Example 2: Flow-Dependent Study
1. **Setup Tab**:
   - Configure nanofluid (as above)
   - Velocity: 0.5 m/s
   - Shear Rate: 1000 1/s
   - ☑️ Enable Non-Newtonian

2. **Analysis Tab**:
   - Click "Calculate Flow-Dependent Properties"

3. **Results Tab**:
   - Compare k_static vs k_flow
   - See flow enhancement contributions

### Example 3: DLVO Stability Analysis
1. **Setup Tab**:
   - Configure nanofluid
   - pH: 7.0
   - Ionic Strength: 0.001 mol/L

2. **Analysis Tab**:
   - Click "🚀 Comprehensive Analysis"

3. **Results Tab**:
   - Check DLVO section:
     - Zeta potential
     - Debye length
     - Energy barrier
     - Stability status (STABLE/UNSTABLE)
     - Cluster size

### Example 4: Base Fluid Only
1. **Setup Tab**:
   - Base Fluid: Water
   - Temperature: 300 K
   - ☑️ Calculate base fluid only (checked)

2. **Analysis Tab**:
   - Click "Calculate Base Fluid Properties Only"

3. **Results Tab**:
   - Get pure water properties at 300 K
   - No nanoparticle effects

---

## 🔬 Advanced Features

### 1. Flow-Dependent Thermal Conductivity
Mathematical models:
- **Buongiorno Two-Component Model**: k = f(Pe_B, Pe_T)
- **Kumar Shear-Enhanced**: k = f(γ̇, γ*)
- **Rea-Guzman Velocity-Dependent**: k = f(Re_p)

Parameters calculated:
- Brownian Peclet number: Pe_B = πd_p³μ_bf u / (18k_B T)
- Thermophoretic Peclet number: Pe_T = β₀d_p |∇T| / u
- Shear number: γ* = γ̇d_p² / D_B

### 2. Non-Newtonian Viscosity Models
Available models:
- **Power-Law**: μ = K γ̇^(n-1)
- **Carreau-Yasuda**: μ = μ_∞ + (μ_0 - μ_∞)[1 + (λγ̇)^a]^((n-1)/a)
- **Cross Model**: μ = μ_∞ + (μ_0 - μ_∞) / (1 + Kγ̇^m)
- **Herschel-Bulkley**: τ = τ_0 + K γ̇^n

Temperature dependence:
- Arrhenius: μ = A exp(E_a / RT)
- VFT: μ = A exp[B / (T - T_0)]

### 3. DLVO Theory
Components:
- **Van der Waals**: V_vdw = -A_H d_p / (12h)
- **Electrostatic**: V_elec = πεζ² exp(-κh)
- **Total**: V_total = V_vdw + V_elec

Material-specific Hamaker constants:
- Al₂O₃: 15.5 × 10⁻²⁰ J
- Cu: 40.0 × 10⁻²⁰ J
- TiO₂: 16.0 × 10⁻²⁰ J
- etc.

pH effects on zeta potential:
- ζ(pH) calculated from isoelectric point
- Debye length: λ_D = √(ε₀εᵣkT / 2N_A e²I)

Clustering:
- Fractal dimension: D_f = 1.8-2.1
- Effects on k and μ calculated

### 4. Enhanced Hybrid Nanofluids
Multiple particles supported:
- Each particle has individual k_p, ρ_p, φ
- Combined effective properties
- Interaction effects considered

### 5. Base Fluid Analysis
Calculate properties of pure fluids:
- k_bf(T, p)
- μ_bf(T)
- ρ_bf(T, p)
- Cp_bf(T)
- α_bf = k / (ρ Cp)

Useful for:
- Baseline comparison
- Enhancement ratio calculation
- Validation against literature
- Educational demonstrations

---

## 📊 Validation

### Experimental Datasets
| Reference | Material | Property | R² | MAPE | Status |
|-----------|----------|----------|-----|------|--------|
| Das et al. (2003) | Al₂O₃-water | k vs φ | 0.958 | 7.2% | ✅ Excellent |
| Eastman et al. (2001) | CuO-water | k vs T | 0.982 | 4.1% | ✅ Excellent |
| Suresh et al. (2012) | Al₂O₃+Cu hybrid | k | 0.926 | 11.5% | ✅ Good |
| Chen et al. (2007) | TiO₂-EG | μ vs φ | 0.935 | 9.8% | ✅ Good |
| Nguyen et al. (2007) | Al₂O₃-water | μ vs γ̇ | 0.884 | 14.3% | ✅ Acceptable |

**Overall**: R² = 0.932, MAPE = 10.0% ✅ **PASSED**

---

## ⚙️ Technical Details

### Build Information
- **PyInstaller**: 5.0+
- **Bundle Mode**: One-file executable
- **Compression**: UPX enabled
- **Dependencies**: Bundled (NumPy, SciPy, matplotlib, PyQt6)

### System Requirements
- **OS**: Windows 10/11 (64-bit)
- **RAM**: 4 GB minimum, 8 GB recommended
- **Disk**: 500 MB for executable + 200 MB temp space
- **Display**: 1280x800 minimum resolution

### File Size
- Executable: ~150-200 MB
- Includes all Python libraries
- Self-contained, no external dependencies

### Performance
- Startup: 3-5 seconds
- Static analysis: < 1 second
- Comprehensive analysis: 5-10 seconds
- Flow-dependent calculations: 2-5 seconds

---

## 🐛 Troubleshooting

### Issue: "Windows protected your PC" Warning
**Solution**:
1. Click "More info"
2. Click "Run anyway"
3. This is normal for unsigned executables

### Issue: Slow Startup
**Solution**:
- First launch extracts files (~3-5 seconds)
- Subsequent launches are faster
- Add to Windows Defender exclusions

### Issue: Application Crashes on Startup
**Solution**:
- Check Windows Event Viewer for details
- Verify Windows 10/11 (64-bit)
- Try running as Administrator
- Check antivirus isn't blocking

### Issue: Calculations Take Too Long
**Solution**:
- Comprehensive analysis is CPU-intensive
- Wait for progress bar completion
- Close other applications
- For large parameter sweeps, use Python scripts

### Issue: Results Look Wrong
**Solution**:
- Check input parameters (especially units)
- Temperature in Kelvin (not Celsius)
- Diameter in nanometers
- Volume fraction as decimal (0.02 = 2%)
- Compare with base fluid properties

---

## 📚 Documentation Files

Included with executable (in same folder):
- `README.md`: Main project documentation
- `QUICK_START_V6.md`: Quick start guide with 6 examples
- `TRANSFORMATION_COMPLETE_V6.md`: v6.0 feature summary
- `docs/SCIENTIFIC_THEORY_V6.md`: 50+ page theory document
- `examples/example_17_bkps_nfl_thermal_demo.py`: Code examples

---

## 📖 Citation

If you use BKPS NFL Thermal v6.0 in your research, please cite:

```bibtex
@software{bkps_nfl_thermal_v6,
  title = {BKPS NFL Thermal v6.0: World-Class Nanofluid Thermal Analysis Software},
  author = {BKPS NFL Thermal Development Team},
  year = {2025},
  version = {6.0},
  note = {Dedicated to Brijesh Kumar Pandey},
  url = {https://github.com/your-repo/bkps-nfl-thermal}
}
```

---

## 🎓 Educational Use

Perfect for:
- **Research**: Publication-quality analysis
- **Teaching**: Demonstrate nanofluid physics
- **Industry**: Design heat exchangers, cooling systems
- **Students**: Learn thermal transport phenomena

Key concepts demonstrated:
- Brownian motion effects
- Thermophoresis
- Shear-rate dependent properties
- Colloidal stability
- Particle-fluid interactions

---

## 🔒 License

MIT License - Free for academic and commercial use

---

## 👨‍💻 Support

For issues, questions, or feature requests:
1. Check troubleshooting section above
2. Review documentation files
3. Examine example code in `examples/`
4. Run validation suite: `python -m nanofluid_simulator.validation_suite`

---

## 🌟 Acknowledgments

**Dedicated to: Brijesh Kumar Pandey**

This software represents world-class professional research-grade analysis, validated against experimental data from:
- Das, Putra, Roetzel (2003)
- Eastman, Choi, Li (2001)
- Suresh, Venkitaraj (2012)
- Chen, Ding (2007)
- Nguyen, Desgranges (2007)

---

## 📝 Version History

### v6.0 (November 2025) - Current
- ✅ Flow-dependent thermal conductivity (6 models)
- ✅ Non-Newtonian viscosity (7 models)
- ✅ DLVO theory & colloidal stability
- ✅ Enhanced hybrid nanofluids (11 materials)
- ✅ Base fluid-only calculations
- ✅ Comprehensive validation (R² = 0.932)
- ✅ 50+ page scientific documentation
- ✅ Standalone Windows executable
- ✅ Professional GUI application

### v5.0 (Previous)
- Static thermal conductivity
- Basic viscosity models
- CFD solver
- Desktop application

---

## 🚀 Future Enhancements (Optional)

Potential future additions:
- Unified single-window GUI
- 300+ DPI publication-quality plots
- Interactive 3D visualizations (Plotly)
- Advanced CFD turbulence models
- Configuration save/load
- Batch processing mode
- Real-time property calculator
- Material database editor

---

**BKPS NFL Thermal v6.0** - ⭐⭐⭐⭐⭐ World-Class Professional Tool  
**Research-Grade | Experimentally Validated | Publication-Quality**

---

*Dedicated to: Brijesh Kumar Pandey*  
*"Advancing nanofluid science through rigorous modeling and validation"*
