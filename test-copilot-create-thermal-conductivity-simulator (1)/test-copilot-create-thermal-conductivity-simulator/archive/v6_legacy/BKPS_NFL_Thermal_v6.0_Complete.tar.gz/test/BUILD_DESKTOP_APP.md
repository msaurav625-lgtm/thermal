# Building Nanofluid Simulator Desktop Application (.exe)

This guide explains how to build a standalone Windows executable for the Nanofluid Simulator.

## 📋 Prerequisites

1. **Python 3.9+** installed
2. **All dependencies** installed
3. **Windows OS** (for .exe building)

## 🚀 Quick Build Steps

### Step 1: Install Desktop Requirements

```bash
pip install -r requirements-desktop.txt
```

This installs:
- PyQt6 (GUI framework)
- PyInstaller (executable builder)
- All simulator dependencies

### Step 2: Build the Application

```bash
# Method 1: Using spec file (recommended)
pyinstaller nanofluid_app.spec

# Method 2: Direct build
pyinstaller --name NanofluidSimulator \
            --windowed \
            --onedir \
            --add-data "README.md;." \
            --add-data "docs;docs" \
            --add-data "examples;examples" \
            --hidden-import nanofluid_simulator \
            --hidden-import PyQt6 \
            --hidden-import matplotlib \
            --hidden-import scipy \
            --hidden-import sklearn \
            nanofluid_app.py
```

### Step 3: Find Your Application

The built application will be in:
```
dist/NanofluidSimulator/NanofluidSimulator.exe
```

### Step 4: Run the Application

Double-click `NanofluidSimulator.exe` to launch!

## 📦 Distribution

To distribute your application:

### Option 1: Folder Distribution
Zip the entire `dist/NanofluidSimulator/` folder and share it.

### Option 2: Single-File Executable (Larger but Simpler)
```bash
pyinstaller --name NanofluidSimulator \
            --windowed \
            --onefile \
            nanofluid_app.py
```

This creates a single `NanofluidSimulator.exe` file (200-300 MB).

## 🎨 Customization

### Add Application Icon

1. Create/obtain an `.ico` file (e.g., `nanofluid_icon.ico`)
2. Modify `nanofluid_app.spec`:
   ```python
   exe = EXE(
       ...
       icon='nanofluid_icon.ico',  # Add this line
       ...
   )
   ```
3. Rebuild: `pyinstaller nanofluid_app.spec`

### Reduce File Size

1. Remove unused dependencies from `hidden_imports` in `.spec` file
2. Exclude large packages:
   ```python
   excludes=[
       'tkinter',
       'test',
       'unittest',
       'IPython',
       'jupyter',
   ],
   ```
3. Use UPX compression (enabled by default)

## 🐛 Troubleshooting

### Issue: "Failed to execute script"
**Solution:** Run with console to see errors:
```python
# In .spec file, change:
console=True  # Instead of False
```

### Issue: Missing DLLs
**Solution:** Ensure all dependencies installed:
```bash
pip install --upgrade --force-reinstall -r requirements-desktop.txt
```

### Issue: ImportError for nanofluid_simulator
**Solution:** Add to PYTHONPATH before building:
```bash
set PYTHONPATH=%CD%
pyinstaller nanofluid_app.spec
```

### Issue: Large File Size (>500 MB)
**Solutions:**
1. Remove unused examples/docs from `datas`
2. Use `--exclude-module` for unused packages
3. Consider virtual environment with minimal packages

## 📊 Expected File Sizes

| Build Type | Size | Description |
|------------|------|-------------|
| One-folder | ~250 MB | Multiple files, faster startup |
| One-file | ~300 MB | Single .exe, slower startup |
| Compressed | ~150 MB | .7z/.zip of one-folder |

## 🚀 Advanced: Auto-Updater

To add auto-update functionality:

1. Install PyUpdater:
   ```bash
   pip install pyupdater
   ```

2. Initialize:
   ```bash
   pyupdater init
   ```

3. Follow PyUpdater documentation for update server setup

## 🧪 Testing the Build

Before distribution, test on a clean Windows machine:

1. ✅ Application launches
2. ✅ All windows open correctly
3. ✅ Property calculator works
4. ✅ CFD simulator runs
5. ✅ AI features function
6. ✅ Results export works
7. ✅ No console errors

## 📝 Distribution Checklist

- [ ] Build tested on clean system
- [ ] All features working
- [ ] README included in dist folder
- [ ] Examples accessible
- [ ] Documentation readable
- [ ] Version number updated
- [ ] License file included
- [ ] Installation instructions provided

## 🌟 Professional Distribution Package

Create professional installer with:

### NSIS (Nullsoft Scriptable Install System)

1. Install NSIS: https://nsis.sourceforge.io/
2. Create installer script:
   ```nsis
   OutFile "NanofluidSimulator_Setup_v5.0.exe"
   InstallDir "$PROGRAMFILES\NanofluidSimulator"
   
   Section "Install"
       SetOutPath "$INSTDIR"
       File /r "dist\NanofluidSimulator\*.*"
       CreateShortcut "$DESKTOP\Nanofluid Simulator.lnk" \
                      "$INSTDIR\NanofluidSimulator.exe"
   SectionEnd
   ```
3. Compile with NSIS

### Inno Setup (Alternative)

1. Install Inno Setup: https://jrsoftware.org/isinfo.php
2. Use Inno Setup Compiler GUI
3. Create professional installer with:
   - Start menu shortcuts
   - Desktop shortcut
   - Uninstaller
   - Custom branding

## 🔒 Code Signing (Optional but Recommended)

For professional distribution without "Unknown Publisher" warnings:

1. Obtain code signing certificate (~$100-300/year)
2. Sign the executable:
   ```bash
   signtool sign /f certificate.pfx /p password /t http://timestamp.digicert.com NanofluidSimulator.exe
   ```

This prevents Windows SmartScreen warnings.

## 💻 Cross-Platform Building

### For Linux:
```bash
pyinstaller --name NanofluidSimulator \
            --windowed \
            nanofluid_app.py
```
Produces: `dist/NanofluidSimulator/NanofluidSimulator` (Linux binary)

### For macOS:
```bash
pyinstaller --name "Nanofluid Simulator" \
            --windowed \
            --osx-bundle-identifier com.nanofluid.simulator \
            nanofluid_app.py
```
Produces: `dist/Nanofluid Simulator.app` (macOS app bundle)

## 📚 Additional Resources

- PyInstaller Manual: https://pyinstaller.org/en/stable/
- PyQt6 Documentation: https://doc.qt.io/qtforpython-6/
- NSIS Documentation: https://nsis.sourceforge.io/Docs/
- Code Signing Guide: https://learn.microsoft.com/en-us/windows/win32/seccrypto/cryptography-tools

## 🎉 Success!

You now have a professional standalone desktop application that:

✅ Runs without Python installation
✅ Has modern multi-window interface
✅ Includes all simulator features
✅ Works on any Windows PC
✅ Is ready for distribution

**Next Steps:**
1. Test on multiple Windows versions (7/10/11)
2. Create professional installer
3. Consider code signing for distribution
4. Share with research community!

---

**Version:** 5.0  
**Last Updated:** November 30, 2025  
**Contact:** GitHub Issues
